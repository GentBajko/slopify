# The River Bank

Narrator: He thought his happiness was complete when, as he meandered aimlessly along, suddenly he stood by the edge of a full-fed river. Never in his life had he seen a river before—this sleek, sinuous, full-bodied animal, chasing and chuckling, gripping things with a gurgle and leaving them with a laugh, to fling itself on fresh playmates that shook themselves free, and were caught and held again.

Narrator: Then the two animals stood and regarded each other cautiously.

Rat: Hullo, Mole!

Narrator: said the Water Rat.

Mole: Hullo, Rat!

Narrator: said the Mole.

Rat: Would you like to come over?

Narrator: enquired the Rat presently.

# Messing About in Boats

Mole: This has been a wonderful day!

Narrator: said he, as the Rat shoved off and took to the sculls again.

Mole: Do you know, I’ve never been in a boat before in all my life.

Rat: What?

Narrator: cried the Rat, open-mouthed:

Rat: Never been in a—you never—well I—what have you been doing, then?

Rat: Believe me, my young friend, there is nothing—absolute nothing—half so much worth doing as simply messing about in boats. Simply messing,

Narrator: he went on dreamily:

Rat: messing—about—in—boats; messing——

Mole: Look ahead, Rat!

Narrator: cried the Mole suddenly.

Narrator: It was too late. The boat struck the bank full tilt. The dreamer, the joyous oarsman, lay on his back at the bottom of the boat, his heels in the air.
